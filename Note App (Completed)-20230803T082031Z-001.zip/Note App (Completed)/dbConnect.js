const mongoose = require("mongoose");

async function dbConnect() {
    try {
        await mongoose.connect("mongodb://0.0.0.0:27017/noteApp");
        console.log("Database Connected");
    } catch (error) {
        console.log(error.message);
    }
}

module.exports = dbConnect;