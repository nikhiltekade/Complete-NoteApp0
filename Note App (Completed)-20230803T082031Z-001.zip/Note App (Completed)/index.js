const express = require("express");
const dbConnect = require("./dbConnect");
const User = require("./models/User");
const bcrypt = require("bcrypt");
const cookieParser = require("cookie-parser");
const Notes = require("./models/Notes");
const jwt = require("jsonwebtoken");
const { isAuthenticated } = require("./middlewares/isAuthenticated");

const app = express();

// request  ->>>>>> server
// Middleware
// response <<<<<<= server

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

dbConnect();

app.set("view engine", "ejs");

app.get("/", isAuthenticated,  async (req, res) => {
    try {
        if (req.cookies.token) {
            const data = await jwt.verify(req.cookies.token, "avichalisgooddeveloperandapythonexpert");

            const notes = await Notes.find({ email: data.email })
            res.render("dashboard", { notes: notes });
        }
        else {
            res.redirect("/login")
        }
    } catch (error) {
        res.render("error", { message: error.message });
    }
});

app.get("/login", (req, res) => {
    res.render("login")
});

app.post("/addNote", async (req, res) => {
    try {
        if (!req.cookies.token) {
            throw new Error("Please Login To Continue!")
        }
        const { title, note } = req.body;

        const myNote = await Notes.create({
            title, note, email: req.cookies.token
        })

        res.render("error", { message: "Note was added Successfully!" })
    } catch (error) {
        res.render("error", { message: error.message })

    }
})

app.get("/signup", (req, res) => {
    res.render("signup")
});

app.get("/logout", (req, res) => {
    res.clearCookie("token");
    res.redirect("/login");
});

app.post("/signup", async (req, res) => {
    try {
        const { email, password, cpassword } = req.body;

        if (!email && !password) {
            throw new Error("Please enter valid credential");
        }

        if (password !== cpassword) {
            throw new Error("Password doesnot Match");
        }

        // const user = await User.create({
        //     email, password
        // })

        const newpassword = await bcrypt.hash(password, 10);

        const user = await User.create({
            email: email, password: newpassword
        })

        res.redirect("/")
    } catch (error) {
        res.render("error", { message: error.message })
    }
});

app.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email && !password) {
            throw new Error("Plase enter valid Credentials!")
        }

        const user = await User.findOne({ email });

        const checkPassword = await bcrypt.compare(password, user.password);

        if (!checkPassword) {
            throw new Error("Invalid Credendtials!");
        }

        const token = await jwt.sign({
            email: email
        }, "avichalisgooddeveloperandapythonexpert")

        console.log(token);

        res.cookie("token", token, {
            expires: new Date(Number(new Date()) + 315360000000),
            httpOnly: true
        });
        res.redirect("/")
    } catch (error) {
        res.render("error", { message: error.message })
    }
})

// GET, POST, PUT, DELETE
app.get("/delete/:id", async (req, res) => {
    try {
        const data = await jwt.verify(req.cookies.token, "avichalisgooddeveloperandapythonexpert");
        const { id } = req.params;

        const note = await Notes.findOne({ _id: id, email: data.email });

        if (!note) {
            throw new Error("Note Doesnot Exists");
        }

        await Notes.findByIdAndDelete(id);

        res.render("error", { message: "Note Deleted Successfully!" });
    } catch (error) {
        res.render("error", { message: error.message });
    }
});

app.post("/update/note", async (req, res) => {
    try {
        const { title, description, noteId } = req.body;
        const todo = await Notes.findByIdAndUpdate(noteId, { title: title, description: description })

        res.render("error", { message: "Todo Updated Successfully!" })
    } catch (error) {
        res.render("error", { message: error.message })
    }
});

app.listen(8000, () => {
    console.log("Listening on PORT 8000");
})