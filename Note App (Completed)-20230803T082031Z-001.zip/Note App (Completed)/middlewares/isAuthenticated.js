const jwt = require("jsonwebtoken");

exports.isAuthenticated = async (req, res, next) => {
    try {
        console.log("Hiiiii");
        if (!req.cookies.token) {
            throw new Error("Login to Continue!");
        }
        else {
            const data = await jwt.verify(req.cookies.token, "avichalisgooddeveloperandapythonexpert");

            next();
        }
    } catch (error) {
        res.render("error", { message: error.message });
    }
}